import React from 'react';
import { MatchScore } from '../types';
import { pixelDistToMeters } from '../physics';

interface GameOverModalProps {
  score: MatchScore;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ score, onRestart }) => {
  const isRedWinner = score.winningTeam === 'RED';
  const isBlueWinner = score.winningTeam === 'BLUE';

  const winnerTitle = isRedWinner
    ? '🔴 1P 赤チームの勝利！'
    : isBlueWinner
    ? '🔵 2P 青チームの勝利！'
    : '🤝 引き分け (DRAW)';

  const winnerPtsText = isRedWinner
    ? `+${score.redPoints} 点獲得！`
    : isBlueWinner
    ? `+${score.bluePoints} 点獲得！`
    : '同点 (0点)';

  const radiusMeters =
    score.scoringRadius != null ? pixelDistToMeters(score.scoringRadius) : null;

  return (
    <div className="w-full max-w-[1024px] my-2 z-20 pointer-events-auto animate-fade-in">
      <div className="glass-panel rounded-2xl p-3 sm:p-4 border-2 border-amber-500/60 shadow-2xl bg-slate-950/95 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Left: Red Team Result Card */}
        <div
          className={`flex items-center space-x-3 p-2.5 rounded-xl border transition-all min-w-[200px] ${
            isRedWinner
              ? 'bg-red-950/60 border-red-500/70 shadow-lg shadow-red-500/20'
              : 'bg-slate-900/60 border-slate-800 opacity-80'
          }`}
        >
          <div className="w-10 h-10 rounded-xl bg-red-600/30 border border-red-500 flex flex-col items-center justify-center font-black font-orbitron text-red-400">
            <span className="text-xs leading-none">RED</span>
            <span className="text-[9px] text-red-200">1P</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[11px] font-black text-red-400">赤チーム (a / w)</span>
            <div className="flex items-baseline space-x-1.5">
              <span className="text-2xl font-black font-orbitron text-white">
                {score.totalRedScore}
              </span>
              <span className="text-[10px] text-slate-400">pts</span>
              <span className="text-xs font-black font-mono text-emerald-400">
                (+{score.redPoints}点)
              </span>
            </div>
            <span className="text-[9.5px] text-slate-400">
              最近球: {score.closestRedDist !== null ? `${score.closestRedDist}m` : '記録なし'}
            </span>
          </div>
        </div>

        {/* Center: Verdict & Scoring Zone Explanation */}
        <div className="flex-1 flex flex-col items-center text-center px-3 py-2 bg-slate-900/80 rounded-xl border border-amber-500/30 w-full">
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xl">🏆</span>
            <span
              className={`text-sm sm:text-base font-black font-orbitron tracking-wide ${
                isRedWinner ? 'text-red-400' : isBlueWinner ? 'text-blue-400' : 'text-amber-400'
              }`}
            >
              {winnerTitle}
            </span>
            <span className="text-amber-300 font-extrabold text-xs sm:text-sm">
              {winnerPtsText} (得点球: {score.scoringBallsCount}個)
            </span>
          </div>

          <p className="text-[11px] text-slate-300 leading-snug">
            コート上の金色の<strong className="text-amber-300">「得点圏内サークル」</strong>(相手最近球まで: {radiusMeters !== null ? `${radiusMeters}m` : '計測'}) 内にある自チーム球が得点球 (★印) です。
          </p>

          <div className="mt-2 flex items-center space-x-3">
            <button
              type="button"
              onClick={onRestart}
              className="px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-xs sm:text-sm tracking-wider shadow-lg shadow-emerald-500/30 hover:brightness-110 active:scale-95 cursor-pointer flex items-center space-x-1.5 border-2 border-transparent"
              title="得点を引き継ぎ、ジャックボール先行投球者を赤1・青2で交代して次のエンドを開始します"
            >
              <span>🔄</span>
              <span>次のエンドへ (先攻交代して開始)</span>
            </button>
          </div>
        </div>

        {/* Right: Blue Team Result Card */}
        <div
          className={`flex items-center space-x-3 p-2.5 rounded-xl border transition-all min-w-[200px] ${
            isBlueWinner
              ? 'bg-blue-950/60 border-blue-500/70 shadow-lg shadow-blue-500/20'
              : 'bg-slate-900/60 border-slate-800 opacity-80'
          }`}
        >
          <div className="flex flex-col items-end flex-1">
            <span className="text-[11px] font-black text-blue-400">青チーム (↓ / →)</span>
            <div className="flex items-baseline space-x-1.5">
              <span className="text-xs font-black font-mono text-emerald-400">
                (+{score.bluePoints}点)
              </span>
              <span className="text-2xl font-black font-orbitron text-white">
                {score.totalBlueScore}
              </span>
              <span className="text-[10px] text-slate-400">pts</span>
            </div>
            <span className="text-[9.5px] text-slate-400">
              最近球: {score.closestBlueDist !== null ? `${score.closestBlueDist}m` : '記録なし'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500 flex flex-col items-center justify-center font-black font-orbitron text-blue-400">
            <span className="text-xs leading-none">BLUE</span>
            <span className="text-[9px] text-blue-200">2P</span>
          </div>
        </div>
      </div>
    </div>
  );
};
