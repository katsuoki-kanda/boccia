import React, { useState } from 'react';
import { BallHoldState, Team, ThrowingBoxNumber, BoxThrowsRecord, MatchType, MATCH_CONFIGS } from '../types';

interface ControlsGuideProps {
  currentTeam: Team;
  holdState: BallHoldState;
  chargeRatio: number;
  selectedBoxNum: ThrowingBoxNumber;
  boxThrowsCount: BoxThrowsRecord;
  aimAngle: number;
  matchType: MatchType;
  isJackThrow?: boolean;
  onToggleHold: () => void;
  onPrevBox: () => void;
  onNextBox: () => void;
  onAimLeft: () => void;
  onAimRight: () => void;
  onStartCharge: () => void;
  onReleaseCharge: () => void;
  onDirectThrow?: (power: number) => void;
}

export const ControlsGuide: React.FC<ControlsGuideProps> = ({
  currentTeam,
  holdState,
  chargeRatio,
  selectedBoxNum,
  boxThrowsCount,
  aimAngle,
  matchType,
  isJackThrow = false,
  onToggleHold,
  onPrevBox,
  onNextBox,
  onAimLeft,
  onAimRight,
  onStartCharge,
  onReleaseCharge,
  onDirectThrow,
}) => {
  const [selectedPresetPower, setSelectedPresetPower] = useState<number>(0.5);
  const isRed = currentTeam === 'RED';
  const isRolling = holdState === 'ROLLING';
  const isCharging = holdState === 'CHARGING';
  const isHolding = holdState === 'HOLD';
  const isIdle = holdState === 'IDLE';

  const matchConfig = MATCH_CONFIGS[matchType];
  const maxThrows = matchConfig.throwsPerBox;

  const themeBorder = isJackThrow
    ? 'border-white/60 shadow-white/10'
    : isRed
    ? 'border-red-500/50'
    : 'border-blue-500/50';
  const themeText = isJackThrow ? 'text-white' : isRed ? 'text-red-400' : 'text-blue-400';

  const key1 = isRed ? 'a' : '↓';
  const key2 = isRed ? 'w' : '→';
  const bothKeys = isRed ? 'a + w' : '↓ + →';

  const ballLabel = isJackThrow ? '⚪ ジャック(白)' : 'ボール';
  const boxThrows = boxThrowsCount[selectedBoxNum] || 0;

  // Aim angle formatted in degrees relative to forward (-90 deg = 0 deg forward)
  const angleDeg = Math.round(((aimAngle + Math.PI / 2) * 180) / Math.PI);

  const handleThrowPointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    if (isRolling) return;
    onStartCharge();
  };

  const handleThrowPointerUp = (e: React.PointerEvent) => {
    e.preventDefault();
    if (isRolling) return;
    onReleaseCharge();
  };

  return (
    <div className="w-full max-w-[1024px] flex flex-col items-center gap-1.5 px-2 py-1 pointer-events-auto">
      {/* Main Operations Control Deck */}
      <div
        className={`glass-panel rounded-2xl px-4 py-2 border ${themeBorder} flex flex-col md:flex-row items-center justify-between gap-3 w-full shadow-xl bg-slate-950/90`}
      >
        {/* Left: Current Player & Mode Status */}
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-slate-900 border border-white/10 flex items-center justify-center text-lg">
            {isJackThrow ? '⚪' : isHolding ? '🎯' : isCharging ? '⚡' : '📦'}
          </div>

          <div className="flex flex-col text-[11px] leading-tight">
            <div className="flex items-center space-x-2">
              <strong className={`${themeText} font-bold text-xs`}>
                {isJackThrow
                  ? `【${isRed ? 'Player 1: 赤組' : 'Player 2: 青組'} 白ジャック先行投球】`
                  : `【${isRed ? 'Player 1: 赤組' : 'Player 2: 青組'} の投球番】`}
              </strong>
              {/* Match Mode & State pills */}
              <span className="px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-amber-950 text-amber-300 border border-amber-600/40">
                {matchConfig.shortName}
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                  isIdle
                    ? 'bg-sky-950/90 text-sky-300 border-sky-500/40'
                    : isHolding
                    ? 'bg-amber-950/90 text-amber-300 border-amber-500/40'
                    : isCharging
                    ? 'bg-red-950/90 text-red-300 border-red-500/40 animate-pulse'
                    : 'bg-slate-800 text-slate-300 border-white/10'
                }`}
              >
                {isIdle
                  ? 'ボックス選択中'
                  : isHolding
                  ? 'ボール構え中 (方向調整)'
                  : isCharging
                  ? '⚡ パワーチャージ中！'
                  : 'ボール転がり中...'}
              </span>
            </div>

            <div className="text-[10px] text-slate-400 mt-1 flex items-center space-x-2">
              <span>
                選択枠: <strong className="text-white font-bold">{`ボックス ${selectedBoxNum}`}</strong> ({boxThrows}/{maxThrows}球)
              </span>
              <span>|</span>
              <span className="text-amber-300 font-mono">
                {isIdle
                  ? `左右操作: ボックス切替 (${key1} / ${key2})`
                  : `左右操作: 方向調整 (${key1} / ${key2})`}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Context-Sensitive Left / Right Operations Deck */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {/* Context A: When in IDLE, buttons cleanly SWITCH BOXES */}
          {isIdle && (
            <div className="flex items-center space-x-1.5 bg-slate-900/90 p-1 rounded-xl border border-sky-500/30 shadow-inner">
              <button
                type="button"
                disabled={isRolling}
                onClick={onPrevBox}
                className="px-2.5 py-1.5 rounded-lg bg-sky-950 hover:bg-sky-900 text-sky-200 border border-sky-500/40 text-xs font-bold transition-all cursor-pointer flex items-center space-x-1"
                title={`前のスローイングボックスに切り替えます (${key1}キー)`}
              >
                <span>◀ 前の枠 ({key1})</span>
              </button>

              <span className="text-[11px] font-bold text-amber-300 px-2 py-0.5 rounded bg-slate-950 border border-white/10 font-mono">
                {`枠【 ${selectedBoxNum} 】`}
              </span>

              <button
                type="button"
                disabled={isRolling}
                onClick={onNextBox}
                className="px-2.5 py-1.5 rounded-lg bg-sky-950 hover:bg-sky-900 text-sky-200 border border-sky-500/40 text-xs font-bold transition-all cursor-pointer flex items-center space-x-1"
                title={`次のスローイングボックスに切り替えます (${key2}キー)`}
              >
                <span>次の枠 ({key2}) ▶</span>
              </button>
            </div>
          )}

          {/* Context B: When HOLDING ball, buttons cleanly adjust AIM DIRECTION */}
          {isHolding && (
            <div className="flex items-center space-x-1.5 bg-slate-900/90 p-1 rounded-xl border border-amber-500/30 shadow-inner">
              <button
                type="button"
                disabled={isRolling}
                onClick={onAimLeft}
                className="px-2.5 py-1.5 rounded-lg bg-amber-950 hover:bg-amber-900 text-amber-200 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer flex items-center space-x-1"
                title={`投球方向を左に回します (${key1}キー)`}
              >
                <span>◀ 狙い左 ({key1})</span>
              </button>

              <span className="text-[11px] font-bold text-amber-300 px-2 py-0.5 rounded bg-slate-950 border border-white/10 font-mono">
                {`${angleDeg > 0 ? '+' : ''}${angleDeg}°`}
              </span>

              <button
                type="button"
                disabled={isRolling}
                onClick={onAimRight}
                className="px-2.5 py-1.5 rounded-lg bg-amber-950 hover:bg-amber-900 text-amber-200 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer flex items-center space-x-1"
                title={`投球方向を右に回します (${key2}キー)`}
              >
                <span>狙い右 ({key2}) ▶</span>
              </button>
            </div>
          )}

          {/* Ball Hold / Release Toggle Button */}
          <button
            type="button"
            disabled={isRolling}
            onClick={onToggleHold}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer flex items-center space-x-1 ${
              isHolding || isCharging
                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/30'
                : 'glass-button text-slate-200 border-white/20 hover:text-white'
            }`}
            title="ボールの構え / 解除を切り替えます"
          >
            <span>{isHolding ? '構え解除 (枠選択へ)' : '🎯 ボールを構える'}</span>
          </button>
        </div>

        {/* Right: Quick Power Presets & High-Performance Throw Button */}
        <div className="flex items-center space-x-2">
          {/* Quick Preset Power selection */}
          <div className="hidden lg:flex items-center space-x-1 bg-slate-900/80 px-2 py-1 rounded-xl border border-white/10">
            <span className="text-[9.5px] text-slate-400 font-bold">強さ:</span>
            {[
              { label: '30%', val: 0.3 },
              { label: '50%', val: 0.5 },
              { label: '75%', val: 0.75 },
              { label: '100%', val: 1.0 },
            ].map((p) => (
              <button
                key={p.label}
                type="button"
                disabled={isRolling}
                onClick={() => {
                  setSelectedPresetPower(p.val);
                  if (onDirectThrow) onDirectThrow(p.val);
                }}
                className={`text-[9px] px-1.5 py-0.5 rounded font-bold cursor-pointer transition-all ${
                  selectedPresetPower === p.val
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
                title={`設定パワー ${p.label} で即時投球`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Main High-Performance Throwing Button */}
          <div className="relative">
            <button
              type="button"
              disabled={isRolling}
              onPointerDown={handleThrowPointerDown}
              onPointerUp={handleThrowPointerUp}
              onPointerCancel={handleThrowPointerUp}
              className={`px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-black tracking-wider transition-all border select-none cursor-pointer flex items-center space-x-1.5 shadow-lg ${
                isCharging
                  ? 'bg-gradient-to-r from-red-500 via-amber-500 to-yellow-400 text-slate-950 border-white scale-105 shadow-amber-500/50 animate-pulse'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 border-emerald-300 hover:brightness-110 active:scale-95 shadow-emerald-500/30'
              } disabled:opacity-40 disabled:cursor-not-allowed`}
              title="長押しでパワーチャージ、離してスロー投球！(ワンクリック投球も可能)"
            >
              <span className="text-sm">{isCharging ? '⚡' : '🎯'}</span>
              <span>
                {isCharging
                  ? `充電中 ${Math.round(chargeRatio * 100)}% (離して投球！)`
                  : 'スローイング (投球)'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
