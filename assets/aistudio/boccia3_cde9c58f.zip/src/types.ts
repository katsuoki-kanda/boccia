export type Team = 'RED' | 'BLUE';

export type BallType = 'JACK' | 'RED' | 'BLUE';

export interface Ball {
  id: string;
  type: BallType;
  ballNumber?: number; // 1-6 for team balls
  boxNumber?: ThrowingBoxNumber; // Which throwing box this ball was launched from
  distFromJack?: number; // Distance in meters from Jack ball
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  mass: number;
  isSettled: boolean;
  isOutOfBounds: boolean;
  invalidNotice?: string;
  colorHex: string;
  lightHex: string;
  darkHex: string;
}

export type ThrowingBoxNumber = 1 | 2 | 3 | 4 | 5 | 6;

export type BoxThrowsRecord = Record<ThrowingBoxNumber, number>;

export type MatchType = 'TEAM' | 'PAIRS' | 'INDIVIDUAL';

export interface MatchTypeConfig {
  type: MatchType;
  name: string;
  shortName: string;
  description: string;
  boxesUsed: ThrowingBoxNumber[];
  redBoxes: ThrowingBoxNumber[];
  blueBoxes: ThrowingBoxNumber[];
  throwsPerBox: number;
  jackStarterBoxes: {
    RED: ThrowingBoxNumber;
    BLUE: ThrowingBoxNumber;
  };
}

export const MATCH_CONFIGS: Record<MatchType, MatchTypeConfig> = {
  TEAM: {
    type: 'TEAM',
    name: '団体戦 (トリオ / 3人制)',
    shortName: '団体戦',
    description: 'スローイングボックス①〜⑥使用・各枠2投',
    boxesUsed: [1, 2, 3, 4, 5, 6],
    redBoxes: [1, 3, 5],
    blueBoxes: [2, 4, 6],
    throwsPerBox: 2,
    jackStarterBoxes: { RED: 1, BLUE: 2 },
  },
  PAIRS: {
    type: 'PAIRS',
    name: 'ペア戦 (ダブルス / 2人制)',
    shortName: 'ペア戦',
    description: 'スローイングボックス②〜⑤使用・各枠3投',
    boxesUsed: [2, 3, 4, 5],
    redBoxes: [2, 4],
    blueBoxes: [3, 5],
    throwsPerBox: 3,
    jackStarterBoxes: { RED: 2, BLUE: 3 },
  },
  INDIVIDUAL: {
    type: 'INDIVIDUAL',
    name: '個人戦 (シングルス / 1人制)',
    shortName: '個人戦',
    description: 'スローイングボックス③・④使用・各枠6投',
    boxesUsed: [3, 4],
    redBoxes: [3],
    blueBoxes: [4],
    throwsPerBox: 6,
    jackStarterBoxes: { RED: 3, BLUE: 4 },
  },
};

export interface ThrowingBoxConfig {
  number: ThrowingBoxNumber;
  team: Team;
  label: string;
  x: number; // Center x in canvas coords
  y: number; // Center y in canvas coords
  width: number;
  height: number;
  isActiveInMode: boolean;
  playerTitle?: string;
}

export type BallHoldState = 'IDLE' | 'HOLD' | 'CHARGING' | 'ROLLING';

export type GamePhase =
  | 'READY' // Start screen
  | 'JACK_THROW' // Initial Jack throw (by Red)
  | 'INITIAL_RED' // First red ball
  | 'INITIAL_BLUE' // First blue ball
  | 'IN_PLAY' // Boccia dynamic turn (furthest from Jack throws)
  | 'MEASURING' // Measuring tape animation
  | 'END_RESULT'; // Match result screen

export interface MatchScore {
  redPoints: number;
  bluePoints: number;
  totalRedScore: number;
  totalBlueScore: number;
  winningTeam: Team | 'DRAW' | null;
  scoringBallsCount: number;
  closestRedDist: number | null;
  closestBlueDist: number | null;
  scoringRadius?: number | null; // Radius of scoring zone circle in canvas pixels
  scoringBallIds?: string[]; // IDs of balls that scored points
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  alpha: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
}
